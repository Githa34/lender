let now = new Date();
document.querySelector('.currentDate').innerText = now.toLocaleDateString(
	"en-GB", 
	{
		weekday: 'long',
		month: "long",
		day: "numeric",
		year: "numeric",
	}
);

let years = document.querySelectorAll('.currentYear');
years.forEach((item) => {
	item.innerText = now.getFullYear();
});